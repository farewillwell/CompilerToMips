package mid_end.llvm_ir.Instrs.IO;

import mid_end.llvm_ir.Instr;

public class IOInstr extends Instr {

}
