package mid_end.llvm_ir.type;

public class LLVMType {

    // 数据的类型，不代表指令的类型。
    @Override
    public String toString() {
        return super.toString();
    }

    public LLVMType getElementType() {
        return null;
    }
}
