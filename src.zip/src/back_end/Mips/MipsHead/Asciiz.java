package back_end.Mips.MipsHead;

public class Asciiz extends Header{
}
