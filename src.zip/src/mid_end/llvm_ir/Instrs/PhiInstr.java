package mid_end.llvm_ir.Instrs;

import mid_end.llvm_ir.Instr;

public class PhiInstr extends Instr {
}
