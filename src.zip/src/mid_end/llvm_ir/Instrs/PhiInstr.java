package mid_end.llvm_ir.Instrs;

import mid_end.llvm_ir.BasicBlock;
import mid_end.llvm_ir.Instr;

import java.util.ArrayList;

public class PhiInstr extends Instr {
    //public final ArrayList<BasicBlock>
}
