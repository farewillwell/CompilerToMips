package mid_end.llvm_ir;

public class StringLiterals extends Value{
    // 如果要优化速度的话还是要整这个，不然每次输出一个字符都要系统调用一次，真的难绷。
}
