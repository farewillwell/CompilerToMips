package mid_end.llvm_ir;

public class StringLiterals extends Value{
}
