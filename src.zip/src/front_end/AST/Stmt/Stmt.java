package front_end.AST.Stmt;

import front_end.AST.Node;

public class Stmt extends Node {

    @Override
    public void show() {
        super.show();
        System.out.println("<Stmt>");
    }
}
