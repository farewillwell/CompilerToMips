package front_end.ErrUseSymbols;

public class ErrUseSymbol {
    public String name;


}
