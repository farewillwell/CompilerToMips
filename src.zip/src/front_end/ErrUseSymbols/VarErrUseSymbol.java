package front_end.ErrUseSymbols;


public class VarErrUseSymbol extends ErrUseSymbol {

    public boolean isConst; //是否为const


}
