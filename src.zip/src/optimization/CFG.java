package optimization;

import mid_end.llvm_ir.Module;

public class CFG {
    //private final Module module;
    // branch jump 有跳转目标


}
