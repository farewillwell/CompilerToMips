package optimization;

public class Mem2Reg {

}
