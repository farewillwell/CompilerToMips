package optimization;

public class DeadCodeRemove {
}
