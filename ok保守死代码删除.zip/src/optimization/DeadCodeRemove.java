package optimization;

import mid_end.llvm_ir.BasicBlock;
import mid_end.llvm_ir.Function;
import mid_end.llvm_ir.IRModule;
import mid_end.llvm_ir.Instr;
import mid_end.llvm_ir.Instrs.BranchInstr;
import mid_end.llvm_ir.Instrs.JumpInstr;

import java.util.HashSet;

public class DeadCodeRemove {
    public void solve(IRModule irModule) {
        for (Function function : irModule.functions) {
            onlyJumpBlockRemove(function);
        }
    }

    private void onlyJumpBlockRemove(Function function) {
        HashSet<BasicBlock> toRemove = new HashSet<>();
        BasicBlock entry = function.basicBlocks.get(0);
        // 这个的实现者似乎还是块本身比较好，对所有前驱进行验证修改，都指到后驱上,把自己的前驱都指到自己的后驱上
        // 确定需要remove的？当然是自己了
        dfsRemoveNextBlock(entry, toRemove, new HashSet<>());
        function.basicBlocks.removeAll(toRemove);
    }

    private void dfsRemoveNextBlock(BasicBlock entry, HashSet<BasicBlock> toRemove, HashSet<BasicBlock> vis) {
        // 后序遍历，先删除当前的子节点,但是可能会爆删除错误.所以我们需要新开一个集合把这个东西先存起来
        // 爆栈怎么办?可能会循环引用?很简单，和之前防止这个的方法一样，加一个遍历集合即可
        vis.add(entry);
        HashSet<BasicBlock> sons = new HashSet<>(entry.next);
        for (BasicBlock son : sons) {
            if (!vis.contains(son)) {
                dfsRemoveNextBlock(son, toRemove, vis);
            }
        }
        // 原则，带有判断逻辑的branch都不删掉，要删只删掉jump的块
        if (entry.instrList.size() == 1 && (entry.instrList.get(0) instanceof JumpInstr)) {
            toRemove.add(entry);
            JumpInstr jumpInstr = (JumpInstr) entry.instrList.get(0);
            BasicBlock target = jumpInstr.getTargetBlock();
            for (BasicBlock father : entry.prev) {
                Instr instr = father.instrList.get(father.instrList.size() - 1);
                if (instr instanceof BranchInstr) {
                    if (((BranchInstr) instr).getThenBlock() == entry) {
                        ((BranchInstr) instr).changeThen(target);
                    } else {
                        ((BranchInstr) instr).changeElse(target);
                    }
                } else {
                    ((JumpInstr) instr).setDstBlock(target);
                }
                // -----------结束后，不要忘了把前驱后驱改变了-------------------
                father.next.remove(entry);
                father.next.add(target);
                target.prev.remove(entry);
                target.prev.add(father);
            }
            entry.prev.clear();
            entry.next.clear();
            // 为彻底删掉做准备
        }
    }

}
