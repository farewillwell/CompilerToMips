import front_end.AST.CompUnit;
import front_end.Lexer;
import front_end.Parser;
import front_end.TokenStream;

import java.io.*;


public class Compiler {
    public static void main(String[] args) {
        File file = new File("testfile.txt");
        long fileLengthLong = file.length();
        byte[] fileContent = new byte[(int) fileLengthLong];
        try {
            FileInputStream inputStream = new FileInputStream("testfile.txt");
            int length = inputStream.read(fileContent);
            inputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        String string = new String(fileContent);
        Lexer lexer = new Lexer(string);
        TokenStream tokenStream = new TokenStream(lexer);
        Parser parser = new Parser(tokenStream);
        CompUnit compUnit = parser.parserComUnit();
        try {
            PrintStream printStream = new PrintStream("output.ll");
            System.setOut(printStream);
            System.out.println(compUnit.getIRCode().toString());
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }

    }
}