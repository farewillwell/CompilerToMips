package mid_end.llvm_ir;

public class UndefinedValue extends Value{

}
