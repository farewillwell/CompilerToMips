package mid_end.symbols;


public class Symbol {
    public String name;

    public Symbol(String name) {
        this.name = name;
    }
}
