package front_end.AST.Fun;

import front_end.AST.Exp.Exp;
import front_end.AST.Node;
import mid_end.llvm_ir.Value;

import java.util.ArrayList;

public class FuncRParams extends Node {
    private final Exp exp;
    private final ArrayList<Exp> otherExps;

    public FuncRParams(Exp exp) {
        this.exp = exp;
        this.otherExps = new ArrayList<>();
    }

    public void addExp(Exp exp) {
        otherExps.add(exp);
    }

    @Override
    public void show() {
        super.show();
        exp.show();
        for (Exp exp1 : otherExps) {
            System.out.println("COMMA ,");
            exp1.show();
        }
        System.out.println("<FuncRParams>");
    }

    public ArrayList<Value> getRealParas() {
        ArrayList<Value> rps = new ArrayList<>();
        rps.add(exp.getIRCode());
        for (Exp exp1 : otherExps) {
            rps.add(exp1.getIRCode());
        }
        return rps;
    }
}
