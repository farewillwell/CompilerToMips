package front_end.AST;

import mid_end.llvm_ir.Value;

public class Node {

    public Node() {

    }

    public void show() {

    }

    public Value getIRCode() {
        return null;
    }

    public int evaluate() {
        throw new RuntimeException("evaluate un valuable node");
    }

}
