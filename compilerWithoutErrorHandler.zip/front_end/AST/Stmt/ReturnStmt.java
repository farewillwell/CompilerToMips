package front_end.AST.Stmt;

import front_end.AST.Exp.Exp;
import mid_end.llvm_ir.IRBuilder;
import mid_end.llvm_ir.Instrs.ReturnInstr;
import mid_end.llvm_ir.User;
import mid_end.llvm_ir.Value;

public class ReturnStmt extends Stmt {
    private final Exp exp;

    public ReturnStmt() {
        this.exp = null;
    }

    public ReturnStmt(Exp exp) {
        this.exp = exp;
    }

    @Override
    public void show() {
        System.out.println("RETURNTK return");
        if (exp != null) {
            exp.show();
        }
        System.out.println("SEMICN ;");
        super.show();
    }

    @Override
    public Value getIRCode() {
        if (exp != null) {
            Value value = exp.getIRCode();
            IRBuilder.IB.addInstrForBlock(new ReturnInstr(value));
        } else {
            IRBuilder.IB.addInstrForBlock(new ReturnInstr());
        }
        return null;
    }
}
