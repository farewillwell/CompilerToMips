package front_end.AST.Stmt;

import front_end.AST.Exp.Exp;
import front_end.AST.TokenNode;
import mid_end.llvm_ir.Constant;
import mid_end.llvm_ir.IRBuilder;
import mid_end.llvm_ir.Instrs.IO.PutCh;
import mid_end.llvm_ir.Instrs.IO.PutInt;
import mid_end.llvm_ir.Value;


import java.util.ArrayList;

public class PrintStmt extends Stmt {
    private final TokenNode formatString;
    private final ArrayList<Exp> exps;

    public PrintStmt(TokenNode tokenNode) {
        this.formatString = tokenNode;
        this.exps = new ArrayList<>();
    }

    public void addExp(Exp exp) {
        exps.add(exp);
    }

    @Override
    public void show() {
        System.out.println("PRINTFTK printf\n" +
                "LPARENT (");
        formatString.show();
        for (Exp exp : exps) {
            System.out.println("COMMA ,");
            exp.show();
        }
        System.out.println("RPARENT )\n" +
                "SEMICN ;");
        super.show();
    }

    @Override
    public Value getIRCode() {
        ArrayList<Value> values = new ArrayList<>();
        for (Exp exp : exps) {
            values.add(exp.getIRCode());
        }
        String str = formatString.content();
        int cur = 0;
        for (int i = 0; i < str.length(); i++) {
            if (str.charAt(i) != '%') {
                IRBuilder.IB.addInstrForBlock(new PutCh(new Constant(str.charAt(i))));
            } else {
                i++;
                IRBuilder.IB.addInstrForBlock(new PutInt(values.get(cur++)));
            }
        }
        return null;
    }
}
