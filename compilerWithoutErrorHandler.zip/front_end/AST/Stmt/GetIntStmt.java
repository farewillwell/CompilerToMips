package front_end.AST.Stmt;

import front_end.AST.Exp.LVal;
import mid_end.llvm_ir.IRBuilder;
import mid_end.llvm_ir.Instrs.IO.GetInt;
import mid_end.llvm_ir.Instrs.StoreInstr;
import mid_end.llvm_ir.Value;

public class GetIntStmt extends Stmt {
    private final LVal lVal;

    public GetIntStmt(LVal lVal) {
        this.lVal = lVal;
    }

    @Override
    public void show() {
        lVal.show();
        System.out.println("ASSIGN =\n" +
                "GETINTTK getint\n" +
                "LPARENT (\n" +
                "RPARENT )\n" +
                "SEMICN ;");
        super.show();
    }

    @Override
    public Value getIRCode() {
        GetInt getInt = new GetInt();
        IRBuilder.IB.addInstrForBlock(getInt);
        StoreInstr storeInstr = new StoreInstr(getInt.getAns(), lVal.getIRAsLeft());
        IRBuilder.IB.addInstrForBlock(storeInstr);
        return null;
    }
}
