package front_end.AST.Stmt;

public class ContinueStmt extends Stmt{
    public ContinueStmt() {

    }

    @Override
    public void show() {
        System.out.println("CONTINUETK continue");
        System.out.println("SEMICN ;");
        super.show();
    }
}
