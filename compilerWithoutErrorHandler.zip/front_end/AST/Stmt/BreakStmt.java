package front_end.AST.Stmt;

public class BreakStmt extends Stmt{
    public BreakStmt() {

    }

    @Override
    public void show() {
        System.out.println("BREAKTK break");
        System.out.println("SEMICN ;");
        super.show();
    }
}
