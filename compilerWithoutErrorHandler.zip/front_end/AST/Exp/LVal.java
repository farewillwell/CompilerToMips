package front_end.AST.Exp;

import front_end.AST.Node;
import front_end.AST.TokenNode;
import mid_end.llvm_ir.GlobalVar;
import mid_end.llvm_ir.IRBuilder;
import mid_end.llvm_ir.Instrs.LoadInstr;
import mid_end.llvm_ir.Value;
import mid_end.llvm_ir.type.BaseType;
import mid_end.symbols.SymbolManager;
import mid_end.symbols.VarSymbol;

import java.util.ArrayList;

public class LVal extends Node {
    private final TokenNode tokenNode;
    private final ArrayList<Exp> exps;

    public LVal(TokenNode tokenNode) {
        this.tokenNode = tokenNode;
        this.exps = new ArrayList<>();
    }

    public void addExp(Exp exp) {
        exps.add(exp);
    }

    @Override
    public void show() {
        tokenNode.show();
        for (Exp exp : exps) {
            System.out.println("LBRACK [");
            exp.show();
            System.out.println("RBRACK ]");
        }
        super.show();
        System.out.println("<LVal>");
    }

    // 默认取出来是整数 TODO 这个值方法返回的是作为值的，我们需要一个方法作为被赋值的东西
    @Override
    public Value getIRCode() {
        LoadInstr loadInstr = new LoadInstr(tokenNode.content(), BaseType.I32);
        IRBuilder.IB.addInstrForBlock(loadInstr);
        return loadInstr.getAns();
    }

    // TODO 这个方法是上面说的需要作为被赋值的码
    public Value getIRAsLeft() {
        return SymbolManager.SM.getVarSymbol(tokenNode.content()).value;
    }

    // 仅仅在全局初始化计算的时候才使用。否则无效
    @Override
    public int evaluate() {
        if (!SymbolManager.SM.isGlobal()) {
            throw new RuntimeException("evaluate in not global state");
        } else {
            VarSymbol varSymbol = SymbolManager.SM.getVarSymbol(tokenNode.content());
            if (!(varSymbol.value instanceof GlobalVar)) {
                throw new RuntimeException("evaluate from not global value");
            }
            return ((GlobalVar) varSymbol.value).getInitValue();
        }
    }
}
