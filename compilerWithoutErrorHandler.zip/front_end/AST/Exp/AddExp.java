package front_end.AST.Exp;

import front_end.AST.Node;
import front_end.AST.TokenNode;
import front_end.RW;
import mid_end.llvm_ir.IRBuilder;
import mid_end.llvm_ir.Instrs.ALUInstr;
import mid_end.llvm_ir.Value;

import java.util.ArrayList;

public class AddExp extends Node {
    private final MulExp mulExp;
    private final ArrayList<TokenNode> tokenNodes;
    private final ArrayList<MulExp> otherMulExps;

    public AddExp(MulExp mulExp) {
        this.mulExp = mulExp;
        this.otherMulExps = new ArrayList<>();
        this.tokenNodes = new ArrayList<>();
    }

    public void addMulExp(TokenNode tokenNode, MulExp mulExp) {
        tokenNodes.add(tokenNode);
        otherMulExps.add(mulExp);
    }

    @Override
    public void show() {
        mulExp.show();
        System.out.println("<AddExp>");
        for (int i = 0; i < otherMulExps.size(); i++) {
            tokenNodes.get(i).show();
            otherMulExps.get(i).show();
            System.out.println("<AddExp>");
        }
        super.show();
    }

    @Override
    public Value getIRCode() {
        Value value = mulExp.getIRCode();
        for (int i = 0; i < otherMulExps.size(); i++) {
            String opcode = tokenNodes.get(i).type() == RW.TYPE.PLUS ? ALUInstr.ADD : ALUInstr.SUB;
            ALUInstr aluInstr = new ALUInstr(opcode, value, otherMulExps.get(i).getIRCode());
            IRBuilder.IB.addInstrForBlock(aluInstr);
            value = aluInstr.getAns();
        }
        return value;
    }

    @Override
    public int evaluate() {
        int ans = mulExp.evaluate();
        for (int i = 0; i < otherMulExps.size(); i++) {
            ans += (tokenNodes.get(i).type() == RW.TYPE.PLUS ? 1 : -1) * otherMulExps.get(i).evaluate();
        }
        return ans;
    }
}
