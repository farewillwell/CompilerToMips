package front_end.AST.Exp;

import front_end.AST.Node;

public class ForStmt extends Node {
    private final LVal lVal;
    private final Exp exp;

    public ForStmt(LVal lVal, Exp exp) {
        this.lVal = lVal;
        this.exp = exp;
    }

    @Override
    public void show() {
        lVal.show();
        System.out.println("ASSIGN =");
        exp.show();
        System.out.println("<ForStmt>");
        super.show();
    }
}
