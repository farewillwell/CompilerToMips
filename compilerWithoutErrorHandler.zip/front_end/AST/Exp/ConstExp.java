package front_end.AST.Exp;

import front_end.AST.Node;

public class ConstExp extends Node {
    private final AddExp addExp;

    public ConstExp(AddExp addExp) {
        this.addExp = addExp;
    }

    @Override
    public void show() {
        addExp.show();
        System.out.println("<ConstExp>");
        super.show();
    }

    @Override
    public int evaluate() {
        return addExp.evaluate();
    }
}
