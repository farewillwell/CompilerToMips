package front_end.AST;

import mid_end.llvm_ir.BasicBlock;
import mid_end.llvm_ir.IRBuilder;
import mid_end.llvm_ir.Value;
import mid_end.symbols.SymbolManager;

import java.util.ArrayList;

public class Block extends Node {
    private final ArrayList<Node> nodes;

    public Block() {
        nodes = new ArrayList<>();
    }

    public void addNode(Node node) {
        nodes.add(node);
    }

    @Override
    public void show() {
        super.show();
        System.out.println("LBRACE {");
        for (Node node : nodes) {
            node.show();
        }
        System.out.println("RBRACE }");
        System.out.println("<Block>");
    }

    @Override
    public Value getIRCode() {
        for (Node node : nodes) {
            node.getIRCode();
        }
        return null;
    }
}
